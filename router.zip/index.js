import express from "express";
import { PORT, MONGODBURL } from "./config.js";
import mongoose from "mongoose";
import main from "./router/main.js";

const app = express();

app.use(express.json());

app.get("/", (req, res) => {
  console.log(req);
  return res.status(234).send("Welcome to bookstore");
});

app.use("/books",main);

mongoose
  .connect(MONGODBURL)
  .then(() => {
    console.log("connection established for db");
    app.listen(PORT, () => {
      console.log(`App is listening to the port : ${PORT}`);
    });
  })
  .catch((err) => {
    console.log(err);
  });
