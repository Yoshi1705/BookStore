
export const PORT = 8080;
export const MONGODBURL = "mongodb+srv://root:root@bookstoremern.ym36kwv.mongodb.net/books-collection?retryWrites=true&w=majority"